// Quiz data
const quizData = {
    sport: [
        {
            question: "Vilket år grundades Sveriges mest framgångsrika lag AIK?",
            options: ["1943", "1891", "1895", "1921"],
            correct: 1
        },
        {
            question: "Vilket av dessa lag har vunnit Champions league flest gånger?",
            options: ["Real madrid", "Manchester united", "Milan", "Dortmund"],
            correct: 0
        },
        {
            question: "Hur många lag är de ursprungliga i NHL",
            options: ["4", "8", "12", "6"],
            correct: 3
        },
        {
            question: "Vad heter Svenska landslagets nationalarena i fotboll",
            options: ["friends arena", "Strawberry arena", "Råsunda", "Swedbank stadium"],
            correct: 1
        },
        {
            question: "Vilket nummer hade Mats Sundin i hockey",
            options: ["19", "26", "13", "35"],
            correct: 2
        },
        {
            question: "Vem anses vara den bästa boxaren genom tiderna",
            options: ["Mike tyson", "Mohammed Ali", "Ingemar Johansson", "Oleksander Usyk"],
            correct: 1
        }
    ],
    geography: [
        {
            question: "Vad är Sveriges huvudstad?",
            options: ["Göteborg", "Malmö", "Stockholm", "Uppsala"],
            correct: 2
        },
        {
            question: "Vilket är världens största land till ytan?",
            options: ["Kina", "USA", "Kanada", "Ryssland"],
            correct: 3
        },
        {
            question: "Vilket hav ligger öster om Sverige?",
            options: ["Östersjön", "Nordsjön", "Atlanten", "Medelhavet"],
            correct: 0
        },
        {
            question: "Vilken är Sveriges längsta flod?",
            options: ["Dalälven", "Klarälven", "Göta älv", "Ångermanälven"],
            correct: 1
        },
        {
            question: "Vilket är Sveriges högsta berg?",
            options: ["Kebnekaise", "Sarektjåkkå", "Helags", "Åre"],
            correct: 0
        },
        {
            question: "Hur många landskap har Sverige?",
            options: ["21", "23", "25", "28"],
            correct: 2
        }
    ]
};

// Global variables
let currentQuestions = [];
let currentQuestionIndex = 0;
let score = 0;
let timer;
let timeLeft;
let quizStartTime;
let currentTopic;
let canAnswer = true;

// Quiz functions
function startQuiz(topic) {
    currentTopic = topic;
    currentQuestions = [...quizData[topic]]
        .sort(() => Math.random() - 0.5)
        .slice(0, 5);
    currentQuestionIndex = 0;
    score = 0;
    quizStartTime = Date.now();
    showScreen('quizScreen');
    showQuestion();
}

function showQuestion() {
    const question = currentQuestions[currentQuestionIndex];
    document.getElementById('question').textContent = question.question;
    
    const optionsContainer = document.getElementById('options');
    optionsContainer.innerHTML = '';
    
    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.className = 'option';
        button.textContent = option;
        button.onclick = () => canAnswer && checkAnswer(index);
        optionsContainer.appendChild(button);
    });

    const feedback = document.getElementById('feedback');
    feedback.className = 'feedback';
    feedback.textContent = '';

    // Update progress bar
    const progress = ((currentQuestionIndex + 1) / currentQuestions.length) * 100;
    document.querySelector('.progress-bar').style.width = `${progress}%`;

    canAnswer = true;
    timeLeft = 20;
    updateTimer();
    if (timer) clearInterval(timer);
    timer = setInterval(updateTimer, 1000);
}

function updateTimer() {
    if (timeLeft >= 0) {
        document.getElementById('timeLeft').textContent = timeLeft;
        if (timeLeft === 0 && canAnswer) {
            canAnswer = false;
            clearInterval(timer);
            showFeedback(false);
            setTimeout(nextQuestion, 1500);
        }
        timeLeft--;
    }
}

function checkAnswer(selectedIndex) {
    if (!canAnswer) return;
    canAnswer = false;
    clearInterval(timer);
    
    const correct = currentQuestions[currentQuestionIndex].correct === selectedIndex;
    if (correct) score++;
    
    showFeedback(correct);
    
    const options = document.querySelectorAll('.option');
    options.forEach(option => option.disabled = true);
    options[selectedIndex].classList.add(correct ? 'correct' : 'wrong');
    options[currentQuestions[currentQuestionIndex].correct].classList.add('correct');

    setTimeout(nextQuestion, 1500);
}

function showFeedback(correct) {
    const feedback = document.getElementById('feedback');
    feedback.textContent = correct ? 'Rätt svar!' : 'Fel svar!';
    feedback.style.backgroundColor = correct ? 'var(--success-color)' : 'var(--error-color)';
    feedback.style.color = 'white';
    feedback.classList.add('visible');
}

function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < currentQuestions.length) {
        showQuestion();
    } else {
        showResults();
    }
}

function showResults() {
    const totalTime = Math.round((Date.now() - quizStartTime) / 1000);
    document.getElementById('finalScore').textContent = score;
    document.getElementById('totalTime').textContent = totalTime;

    const bestTimeKey = `bestTime_${currentTopic}`;
    let bestTime = localStorage.getItem(bestTimeKey);
    if (!bestTime || (totalTime < parseInt(bestTime) && score > 0)) {
        localStorage.setItem(bestTimeKey, totalTime);
        bestTime = totalTime;
    }
    document.getElementById('bestTime').textContent = bestTime || '-';

    showScreen('resultsScreen');
}

function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
}

function restartQuiz() {
    showScreen('startScreen');
}